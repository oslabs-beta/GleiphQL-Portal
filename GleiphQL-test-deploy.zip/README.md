# web-app instructions
// Replace later in package.json script
// "dev": "concurrently \"cd ./TS_src/client && vite\" \"cd ./TS_src/server && nodemon server.ts\"",

 <!-- <BrowserRouter>
    <App />
  </BrowserRouter>,
) -->